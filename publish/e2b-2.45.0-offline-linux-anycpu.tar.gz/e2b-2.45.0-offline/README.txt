E2B JavaScript SDK 2.45.0 离线安装包

要求：
- Linux x64 或 ARM64
- Node.js 20 或更高版本
- npm

使用方法：
1. 将整个 e2b-2.45.0-offline 目录复制并解压到内网机器。
2. 进入需要使用 E2B SDK 的 Node.js 项目目录。
3. 执行：

   /path/to/e2b-2.45.0-offline/install.sh

安装脚本只使用包内 npm-cache，不访问网络，并将 e2b@2.45.0 精确写入当前项目依赖。

验证：

   npm ls e2b

预期显示 e2b@2.45.0。
