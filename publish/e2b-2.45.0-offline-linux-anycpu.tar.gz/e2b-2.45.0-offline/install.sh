#!/bin/sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

if ! command -v npm >/dev/null 2>&1; then
  echo "npm is required but was not found in PATH" >&2
  exit 1
fi

npm install \
  --offline \
  --cache "$SCRIPT_DIR/npm-cache" \
  --registry https://registry.npmjs.org \
  --save-exact \
  e2b@2.45.0 \
  "$@"
