# agentsphere-e2b-patch (JavaScript / TypeScript)

给官方 [E2B JS SDK](https://www.npmjs.com/package/e2b) 打补丁，让访问 envd（端口 **49983**）的请求自动带上 create sandbox 返回的 `trafficAccessToken`。

请从本包引入 `Sandbox` / `E2B`，不要从 `e2b` 引入这两个符号。

## 安装

```bash
npm install e2b agentsphere-e2b-patch
```

## 使用

```ts
import { Sandbox } from 'agentsphere-e2b-patch'

const sandbox = await Sandbox.create({
  domain: 'your-compat-domain.example',
})
await sandbox.commands.run('echo ok')
```

绑定了连接配置的 client：

```ts
import { E2B } from 'agentsphere-e2b-patch'

const client = new E2B({ apiKey: 'e2b_...', domain: 'your-compat-domain.example' })
const sandbox = await client.Sandbox.create()
```

`Volume` / `Template` 等其它 API 仍可从 `e2b` 引入，本包也再导出了一部分常用符号。

## 非 envd 端口

用户自己请求 `sandbox.getHost(8080)` 时，SDK 不会代发，需要自己带头：

```ts
import { trafficHeaders } from 'agentsphere-e2b-patch'

await fetch(`https://${sandbox.getHost(8080)}`, {
  headers: trafficHeaders(sandbox),
})
```

## 开发

```bash
cd agentsphere-e2b-patch-js
npm install
make test
make build    # 产物在 dist/
make clean
make tar      # clean + build 后打成 publish/agentsphere-e2b-patch-<version>.tgz
```

`make tar` 会排除 `node_modules/`、`publish/` 和 `.git/`。用户可用 `npm install ./agentsphere-e2b-patch-0.1.0.tgz` 安装（需同时安装 `e2b`）。
